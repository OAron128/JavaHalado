package program;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Program extends JFrame {

	private Color paleYellow = new Color(255,255,170);
	private JPanel contentPane;
	private JLabel[][] Field = new JLabel[12][12];
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Program frame = new Program();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Program() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Treasure Hunter");
		setSize(620,720);
		setLocationRelativeTo(null);
		//setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(paleYellow);
		instantiation();
		trackDrawer();
		setContentPane(contentPane);
		contentPane.setLayout(null);
	}
	
	public void instantiation() {
		for (int j = 0; j < 12; j++) {
			for (int i = 0; i < 12; i++) {
				Field[i][j]= new JLabel();
			}
			
		}
	}
	
	public void trackDrawer() {
		for (int i = 0; i < 12; i++) {
			if(i==0) Field[i][0].setIcon(new ImageIcon("pict\\topLeftCorner.png"));
			else if ( i==11) Field[i][0].setIcon(new ImageIcon("pict\\topRightCorner.png"));
			else Field[i][0].setIcon(new ImageIcon("pict\\topLine.png"));
			contentPane.add(Field[i][0]);
			Field[i][0].setBounds(10+i*50,10,50,50);
		}
		for (int j = 1; j < 11; j++) {
			for (int i = 0; i < 12; i++) {
				if(i==0) Field[i][j].setIcon(new ImageIcon("pict\\rightLine.png"));
				if(i==11) Field[i][j].setIcon(new ImageIcon("pict\\leftLine.png"));
				if(i>0 && i<11) Field[i][j].setIcon(new ImageIcon("pict\\trackBase.png"));
				contentPane.add(Field[i][j]);
				Field[i][j].setBounds(10+i*50,10+j*50,50,50);
			}
		}
		for (int i = 0; i < 12; i++) {
			if(i==0) Field[i][11].setIcon(new ImageIcon("pict\\bottomLeftCorner.png"));
			else if (i==11) Field[i][11].setIcon(new ImageIcon("pict\\bottomRightCorner.png"));
			else Field[i][11].setIcon(new ImageIcon("pict\\bottomLine.png"));
			contentPane.add(Field[i][11]);
			Field[i][11].setBounds(10+i*50,560,50,50);
		}
	}

}
